from setuptools import setup
from .genai_cmd import start
import argparse

if __name__ == '__main__':
    start()